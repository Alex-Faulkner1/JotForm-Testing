"""
JotForm Payment Request Test Suite Runner - WITH AUTOMATED EMAIL LINK RETRIEVAL
Executes predefined test cases and generates Excel reports
Now automatically retrieves approval links from YOPmail!
"""
import asyncio
import json
from datetime import datetime
from pathlib import Path
from playwright.async_api import async_playwright, Page
from utils import make_test_pdf, extract_efs_ref, create_output_folder
from config import JOTFORM_URL, HEADLESS_MODE, WORKFLOW_WAIT_TIME, REDIRECT_TIMEOUT
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

# Import our YOPmail link retriever
from yopmail_link_retriever import get_approval_link_for_test


class TestResult:
    """Store test execution results."""
    def __init__(self, test_id, test_name, form_type, scenario):
        self.test_id = test_id
        self.test_name = test_name
        self.form_type = form_type
        self.scenario = scenario
        self.status = "NOT_RUN"
        self.efs_ref = None
        self.start_time = None
        self.end_time = None
        self.duration = None
        self.expected_outcome = None
        self.actual_outcome = None
        self.error_message = None
        self.screenshots = []
        self.approval_links = []
    
    def to_dict(self):
        """Convert to dictionary for Excel export."""
        return {
            'Test ID': self.test_id,
            'Test Name': self.test_name,
            'Form Type': self.form_type,
            'Scenario': self.scenario,
            'Status': self.status,
            'EFS Ref': self.efs_ref,
            'Start Time': self.start_time.strftime('%Y-%m-%d %H:%M:%S') if self.start_time else '',
            'End Time': self.end_time.strftime('%Y-%m-%d %H:%M:%S') if self.end_time else '',
            'Duration (s)': f"{self.duration:.2f}" if self.duration else '',
            'Expected Outcome': self.expected_outcome,
            'Actual Outcome': self.actual_outcome,
            'Error Message': self.error_message or '',
            'Screenshots': ', '.join(self.screenshots),
        }


class TestRunner:
    """Main test runner class with automated email link retrieval."""
    
    def __init__(self, test_suite_file: str, output_folder: str = "test_results", 
                 auto_retrieve_links: bool = True):
        self.test_suite_file = test_suite_file
        self.output_folder = output_folder
        self.test_cases = []
        self.results = []
        self.page = None
        self.user_email = None
        self.auto_retrieve_links = auto_retrieve_links
        
        # Create output folder
        Path(self.output_folder).mkdir(parents=True, exist_ok=True)
    
    def load_test_suite(self):
        """Load test suite from JSON file."""
        print(f"\n📂 Loading test suite from: {self.test_suite_file}")
        with open(self.test_suite_file, 'r') as f:
            self.test_cases = json.load(f)
        print(f"✅ Loaded {len(self.test_cases)} test cases")
    
    def get_user_email(self):
        """Get user email for approval workflows."""
        print("\n" + "=" * 60)
        print("Test Suite Configuration")
        print("=" * 60)
        email = input("Enter your email for approvals [alex.faulkner@digiblu.com]: ").strip()
        if not email:
            email = "alex.faulkner@digiblu.com"
        self.user_email = email
        print(f"✅ Using email: {self.user_email}")
        print(f"🤖 Auto-retrieve links: {'ENABLED' if self.auto_retrieve_links else 'DISABLED'}")
        print()
    
    def get_approval_link(self, stage_name: str, efs_ref: str) -> str:
        """
        Get approval link - automatically from YOPmail or manual input.
        
        Args:
            stage_name: Approver stage (e.g., "PCM", "RD", "RCM")
            efs_ref: EFS Reference number
        
        Returns:
            Approval link URL
        """
        print("\n" + "=" * 60)
        print(f"📧 {stage_name} Approval Link Required")
        print("=" * 60)
        print(f"EFS Ref: {efs_ref}")
        
        if self.auto_retrieve_links:
            print(f"🤖 Attempting automatic retrieval from YOPmail...")
            
            try:
                # Try to get link automatically from YOPmail
                link = get_approval_link_for_test(stage_name, efs_ref)
                
                if link:
                    print(f"\n✅ Link retrieved automatically!")
                    print(f"🔗 {link}")
                    print("=" * 60 + "\n")
                    return link
                else:
                    print(f"\n⚠️  Automatic retrieval failed")
                    print(f"Falling back to manual input...\n")
            
            except Exception as e:
                print(f"\n⚠️  Error during automatic retrieval: {e}")
                print(f"Falling back to manual input...\n")
        
        # Manual input fallback
        print(f"\nCheck your email for the {stage_name} approval email.")
        if stage_name == "PCM":
            print("Expected link format: https://eel.jotform.com/edit/############?eapeo1e")
        elif stage_name == "RD":
            print("Expected link format: https://eel.jotform.com/edit/############?eapet2e")
        print("=" * 60 + "\n")
        
        link = input(f"Paste {stage_name} link (or 'skip'): ").strip()
        return link if link.lower() != 'skip' else None
    
    async def wait_for_redirect(self, initial_url: str, timeout: int = REDIRECT_TIMEOUT) -> bool:
        """Wait for page redirect after form submission."""
        await self.page.wait_for_timeout(timeout)
        current_url = self.page.url
        
        # Check if we're already on a different page (redirect happened)
        if current_url != initial_url:
            print(f"✅ Redirected to: {self.page.url}")
            return True

        # If still on same page, check for success indicators before retrying
        try:
            # Check if "Thank You" or success message is visible (redirect happened but URL didn't update)
            success_indicators = [
                "text=Thank You",
                "text=Fully Approved",
                "text=This Form is Fully Approved",
            ]

            for indicator in success_indicators:
                element = await self.page.query_selector(indicator)
                if element and await element.is_visible():
                    print(f"✅ Success page detected (URL may not have changed)")
                    return True
        except:
            pass

        # Still on form page, try clicking submit again
        print("⚠️  No redirect detected, retrying...")
        try:
            # Check if submit button still exists
            submit_button = await self.page.query_selector("#input_98")
            if submit_button:
                await self.page.click("#input_98")
                await self.page.wait_for_timeout(timeout)

                # Check again if redirect happened
                if self.page.url != initial_url:
                    print(f"✅ Redirected to: {self.page.url}")
                    return True
        except Exception as e:
            # Button may not exist anymore - check if we're on success page
            if self.page.url != initial_url:
                print(f"✅ Redirected to: {self.page.url}")
                return True
            print(f"⚠️  Error clicking submit button: {e}")

        print("❌ Redirect failed")
        return False

    async def select_approver(self):
        """Select approver from ActiveDirectory dropdown."""
        try:
            await self.page.wait_for_timeout(3000)
            frames = self.page.frames

            ad_frames = [(i, f) for i, f in enumerate(frames)
                        if "ActiveDirectoryDropDown.html" in (f.url or "")]

            if not ad_frames:
                print("⚠️  No ActiveDirectory iframe found")
                return

            for frame_idx, frame in ad_frames:
                try:
                    dropdown = await frame.query_selector("#input_ADDropdown")
                    if dropdown:
                        await frame.wait_for_timeout(1000)
                        options = await dropdown.query_selector_all("option")

                        if len(options) > 1:
                            await frame.select_option("#input_ADDropdown",
                                                     value=await options[1].get_attribute("value"))
                            approver_name = await options[1].text_content()
                            print(f"✅ Selected approver: {approver_name}")
                            return
                except:
                    continue

            print("⚠️  Could not select approver automatically")
        except Exception as e:
            print(f"⚠️  Error selecting approver: {e}")

    async def fill_form(self, test_data: dict):
        """Fill the JotForm with test data."""
        print("\n" + "=" * 60)
        print("Filling Form")
        print("=" * 60)

        await self.page.goto(JOTFORM_URL)
        await self.page.wait_for_timeout(2000)

        # Company/Division
        await self.page.select_option("#input_123", label=test_data["company_division"])
        print(f"✓ Company/Division: {test_data['company_division']}")

        # Location Number
        await self.page.fill("#input_124", test_data["location_number"])
        print(f"✓ Location Number: {test_data['location_number']}")

        # Raised By
        await self.page.fill("#input_131", test_data["raised_by"])
        print(f"✓ Raised By: {test_data['raised_by']}")

        # Payment Request Date (auto-filled)
        date_value = await self.page.input_value("#lite_mode_130")
        print(f"✓ Payment Request Date: {date_value}")

        # Payment Type
        await self.page.select_option("#input_3", label=test_data["payment_type"])
        print(f"✓ Payment Type: {test_data['payment_type']}")
        await self.page.wait_for_timeout(1000)

        # Description
        await self.page.fill("#input_4", test_data["description"])
        print(f"✓ Description: {test_data['description']}")

        # Payee
        await self.page.fill("#input_5", test_data["payee"])
        print(f"✓ Payee: {test_data['payee']}")

        # Form-specific fields based on payment type
        payment_type = test_data["payment_type"]

        if payment_type == "Goods for Resale":
            await self._fill_goods_for_resale(test_data)
        elif payment_type == "Expense Payments":
            await self._fill_expense_payments(test_data)
        elif payment_type == "Sponsorship/Charitable Donation":
            await self._fill_sponsorship(test_data)
        elif payment_type == "Customer Rebate":
            await self._fill_customer_rebate(test_data)
        elif payment_type == "Sales Ledger Refund":
            await self._fill_sales_ledger_refund(test_data)
        elif payment_type == "Employee Expense Advance":
            await self._fill_employee_expense_advance(test_data)

        print("=" * 60)

    async def _fill_goods_for_resale(self, test_data: dict):
        """Fill Goods for Resale specific fields."""
        # Payment in advance
        if not test_data.get("payment_in_advance", False):
            await self.page.check("#input_79_0")
            print("✓ Payment in advance: No")

        # Number of payable documents
        await self.page.fill("#input_81", test_data.get("payable_documents_count", "1"))
        print(f"✓ Payable documents: {test_data.get('payable_documents_count', '1')}")

        # Currency
        if test_data.get("currency_gbp", True):
            await self.page.check("#input_82_0")
            print("✓ Currency: GBP")

        # Invoice details
        if test_data.get("has_invoice", True):
            await self.page.check("#input_87_0")
            await self.page.fill("#input_88", test_data.get("invoice_number", ""))
            print(f"✓ Invoice: Yes - {test_data.get('invoice_number', '')}")

        # Value
        await self.page.fill("#input_8", test_data.get("value", ""))
        print(f"✓ Value: £{test_data.get('value', '')}")

        # Bank details
        if test_data.get("bank_details_on_invoice", True):
            await self.page.check("#input_10_0")
            print("✓ Bank details: On invoice")

    async def _fill_expense_payments(self, test_data: dict):
        """Fill Expense Payments specific fields."""
        # Payment in advance
        if not test_data.get("payment_in_advance", False):
            await self.page.check("#input_79_0")
            print("✓ Payment in advance: No")

        # Number of payable documents
        await self.page.fill("#input_81", test_data.get("payable_documents_count", "1"))
        print(f"✓ Payable documents: {test_data.get('payable_documents_count', '1')}")

        # Currency
        if test_data.get("currency_gbp", True):
            await self.page.check("#input_82_0")
            print("✓ Currency: GBP")

        # Invoice details
        if test_data.get("has_invoice", True):
            await self.page.check("#input_87_0")
            await self.page.fill("#input_88", test_data.get("invoice_number", ""))
            print(f"✓ Invoice: Yes - {test_data.get('invoice_number', '')}")

        # Value
        await self.page.fill("#input_8", test_data.get("value", ""))
        print(f"✓ Value: £{test_data.get('value', '')}")

        # Bank details
        if test_data.get("bank_details_on_invoice", True):
            await self.page.check("#input_10_0")
            print("✓ Bank details: On invoice")

    async def _fill_sponsorship(self, test_data: dict):
        """Fill Sponsorship/Charitable Donation specific fields."""
        # Invoice details
        if test_data.get("has_invoice", True):
            await self.page.check("#input_87_0")
            await self.page.fill("#input_88", test_data.get("invoice_number", ""))
            print(f"✓ Invoice: Yes - {test_data.get('invoice_number', '')}")

        # Value
        await self.page.fill("#input_8", test_data.get("value", ""))
        print(f"✓ Value: £{test_data.get('value', '')}")

        # Bank details
        if test_data.get("bank_details_on_invoice", True):
            await self.page.check("#input_10_0")
            print("✓ Bank details: On invoice")

    async def _fill_customer_rebate(self, test_data: dict):
        """Fill Customer Rebate specific fields."""
        # Similar to other types - implement as needed
        await self.page.fill("#input_8", test_data.get("value", ""))
        print(f"✓ Value: £{test_data.get('value', '')}")

    async def _fill_sales_ledger_refund(self, test_data: dict):
        """Fill Sales Ledger Refund specific fields."""
        # Similar to other types - implement as needed
        await self.page.fill("#input_8", test_data.get("value", ""))
        print(f"✓ Value: £{test_data.get('value', '')}")

    async def _fill_employee_expense_advance(self, test_data: dict):
        """Fill Employee Expense Advance specific fields."""
        # Similar to other types - implement as needed
        await self.page.fill("#input_8", test_data.get("value", ""))
        print(f"✓ Value: £{test_data.get('value', '')}")

    async def submit_form(self) -> str:
        """Submit the form and extract EFS Reference."""
        print("\n" + "=" * 60)
        print("Submitting Form")
        print("=" * 60)

        # Select approver if needed
        await self.select_approver()

        # Scroll to submit button
        await self.page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        await self.page.wait_for_timeout(1000)

        # Click submit
        initial_url = self.page.url
        await self.page.click("#input_98")
        print("✓ Submit clicked")

        # Wait for redirect
        redirect_success = await self.wait_for_redirect(initial_url)

        if not redirect_success:
            raise Exception("Form submission failed - no redirect")

        # Extract EFS Reference from thank you page
        await self.page.wait_for_timeout(2000)
        page_content = await self.page.content()
        efs_ref = extract_efs_ref(page_content)

        if efs_ref:
            print(f"✅ EFS Reference: {efs_ref}")
        else:
            print("⚠️  Could not extract EFS Reference")

        print("=" * 60)
        return efs_ref

    async def process_approval(self, stage_name: str, action: str, efs_ref: str) -> str:
        """Process an approval stage."""
        print("\n" + "=" * 60)
        print(f"Processing {stage_name} Approval")
        print("=" * 60)

        # Get approval link (automatically or manually)
        link = self.get_approval_link(stage_name, efs_ref)

        if not link:
            raise Exception(f"No approval link provided for {stage_name}")

        # Navigate to approval form
        await self.page.goto(link)
        await self.page.wait_for_timeout(3000)

        print(f"✓ Opened {stage_name} approval form")

        # Take action
        initial_url = self.page.url

        if action == "Approve":
            await self.page.click("#input_100_0")  # Approve radio
            print("✓ Selected: Approve")
        elif action == "Reject":
            await self.page.click("#input_100_1")  # Reject radio
            print("✓ Selected: Reject")

        await self.page.wait_for_timeout(1000)

        # Submit approval
        await self.page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        await self.page.wait_for_timeout(500)
        await self.page.click("#input_98")
        print("✓ Submitted approval")

        # Wait for redirect
        await self.wait_for_redirect(initial_url)
        await self.page.wait_for_timeout(2000)

        # Determine outcome
        page_content = await self.page.content()
        outcome = self._determine_outcome(page_content, action)

        print(f"✅ Outcome: {outcome}")
        print("=" * 60)

        return outcome

    def _determine_outcome(self, page_content: str, action: str) -> str:
        """Determine the outcome from the thank you page."""
        content_lower = page_content.lower()

        if "fully approved" in content_lower or "this form is fully approved" in content_lower:
            return "Form fully approved"
        elif "deleted" in content_lower or "has been deleted" in content_lower:
            return "Form DELETED"
        elif "sent back" in content_lower or "returned to" in content_lower:
            return "Sent back to App 1"
        elif action == "Approve":
            return "Approval submitted (awaiting next stage)"
        elif action == "Reject":
            return "Rejection submitted"
        else:
            return "Unknown outcome"

    async def run_test_case(self, test_case: dict) -> TestResult:
        """Execute a single test case."""
        result = TestResult(
            test_case["test_id"],
            test_case["description"],
            test_case["form_type"],
            test_case["scenario"]
        )

        result.start_time = datetime.now()
        result.expected_outcome = test_case["expected_outcome"]

        try:
            print(f"\n{'='*60}")
            print(f"Test ID: {test_case['test_id']}")
            print(f"Description: {test_case['description']}")
            print(f"{'='*60}")

            # Fill and submit form
            await self.fill_form(test_case["test_data"])
            efs_ref = await self.submit_form()
            result.efs_ref = efs_ref

            # Process approval workflow
            for workflow_step in test_case["approval_workflow"]:
                outcome = await self.process_approval(
                    workflow_step["stage"],
                    workflow_step["action"],
                    efs_ref
                )
                result.actual_outcome = outcome

                # If form is deleted or fully approved, workflow ends
                if "deleted" in outcome.lower() or "fully approved" in outcome.lower():
                    break

            # Determine pass/fail
            if result.expected_outcome and result.actual_outcome:
                expected = result.expected_outcome.lower()
                actual = result.actual_outcome.lower()

                # Flexible matching for rejection scenarios
                if ("deleted" in expected and "deleted" in actual) or \
                   ("sent back" in expected and "sent back" in actual) or \
                   ("return" in expected and "sent back" in actual) or \
                   (expected in actual) or \
                   (actual in expected):
                    result.status = "PASS"
                else:
                    result.status = "FAIL"
                    result.error_message = f"Expected '{result.expected_outcome}' but got '{result.actual_outcome}'"

            result.end_time = datetime.now()
            result.duration = (result.end_time - result.start_time).total_seconds()

            print(f"\n✅ Test {result.test_id} completed: {result.status}")

        except Exception as e:
            result.status = "ERROR"
            result.error_message = str(e)
            result.end_time = datetime.now()
            result.duration = (result.end_time - result.start_time).total_seconds()
            print(f"\n❌ Test {result.test_id} error: {e}")
            import traceback
            traceback.print_exc()

        return result

    def generate_excel_report(self):
        """Generate Excel report with test results."""
        print("\n📊 Generating Excel report...")

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Test Results"

        # Define styles
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF", size=12)
        pass_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
        fail_fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
        error_fill = PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid")

        border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )

        # Headers
        headers = [
            'Test ID', 'Test Name', 'Form Type', 'Scenario', 'Status',
            'EFS Ref', 'Start Time', 'End Time', 'Duration (s)',
            'Expected Outcome', 'Actual Outcome', 'Error Message'
        ]

        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num)
            cell.value = header
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal='center', vertical='center')
            cell.border = border

        # Data rows
        for row_num, result in enumerate(self.results, 2):
            data = result.to_dict()

            for col_num, header in enumerate(headers, 1):
                cell = ws.cell(row=row_num, column=col_num)
                cell.value = data.get(header, '')
                cell.alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)
                cell.border = border

                # Color code status
                if header == 'Status':
                    if data['Status'] == 'PASS':
                        cell.fill = pass_fill
                    elif data['Status'] == 'FAIL':
                        cell.fill = fail_fill
                    elif data['Status'] == 'ERROR':
                        cell.fill = error_fill

        # Adjust column widths
        column_widths = {
            'A': 12,  # Test ID
            'B': 40,  # Test Name
            'C': 20,  # Form Type
            'D': 25,  # Scenario
            'E': 12,  # Status
            'F': 15,  # EFS Ref
            'G': 20,  # Start Time
            'H': 20,  # End Time
            'I': 12,  # Duration
            'J': 30,  # Expected
            'K': 30,  # Actual
            'L': 50,  # Error
        }

        for col, width in column_widths.items():
            ws.column_dimensions[col].width = width

        # Add summary sheet
        summary_ws = wb.create_sheet("Summary")
        summary_ws['A1'] = "Test Execution Summary"
        summary_ws['A1'].font = Font(bold=True, size=14)

        total_tests = len(self.results)
        passed = sum(1 for r in self.results if r.status == "PASS")
        failed = sum(1 for r in self.results if r.status == "FAIL")
        errors = sum(1 for r in self.results if r.status == "ERROR")

        summary_data = [
            ["", ""],
            ["Total Tests", total_tests],
            ["Passed", passed],
            ["Failed", failed],
            ["Errors", errors],
            ["Pass Rate", f"{(passed/total_tests*100):.1f}%" if total_tests > 0 else "N/A"],
            ["", ""],
            ["Execution Date", datetime.now().strftime("%Y-%m-%d %H:%M:%S")],
        ]

        for row_num, (label, value) in enumerate(summary_data, 2):
            summary_ws[f'A{row_num}'] = label
            summary_ws[f'B{row_num}'] = value
            if label:
                summary_ws[f'A{row_num}'].font = Font(bold=True)

        summary_ws.column_dimensions['A'].width = 20
        summary_ws.column_dimensions['B'].width = 20

        # Save workbook
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = f"{self.output_folder}/test_results_{timestamp}.xlsx"
        wb.save(report_file)

        print(f"✅ Excel report saved: {report_file}")
        return report_file

    async def run_all_tests(self):
        """Execute all test cases in the suite."""
        self.load_test_suite()
        self.get_user_email()

        print(f"\n{'='*60}")
        print(f"Starting test execution: {len(self.test_cases)} tests")
        print(f"{'='*60}\n")

        async with async_playwright() as p:
            browser = await p.firefox.launch(headless=HEADLESS_MODE)
            self.page = await browser.new_page()

            try:
                for i, test_case in enumerate(self.test_cases, 1):
                    print(f"\n{'#'*60}")
                    print(f"TEST {i} of {len(self.test_cases)}")
                    print(f"{'#'*60}")

                    result = await self.run_test_case(test_case)
                    self.results.append(result)

                    # Brief pause between tests
                    if i < len(self.test_cases):
                        print("\n⏸️  Pausing 5 seconds before next test...")
                        await self.page.wait_for_timeout(5000)

            finally:
                print("\n⏸️  Closing browser in 5 seconds...")
                await self.page.wait_for_timeout(5000)
                await browser.close()

        # Generate report
        report_file = self.generate_excel_report()

        # Print summary
        print(f"\n{'='*60}")
        print("TEST EXECUTION COMPLETE")
        print(f"{'='*60}")
        print(f"Total Tests: {len(self.results)}")
        print(f"Passed: {sum(1 for r in self.results if r.status == 'PASS')}")
        print(f"Failed: {sum(1 for r in self.results if r.status == 'FAIL')}")
        print(f"Errors: {sum(1 for r in self.results if r.status == 'ERROR')}")
        print(f"\n📊 Report: {report_file}")
        print(f"📁 Screenshots: {self.output_folder}")
        print(f"{'='*60}\n")


async def main():
    """Main entry point."""
    runner = TestRunner(
        test_suite_file="test_suite.json",
        output_folder="test_results",
        auto_retrieve_links=True  # Set to False to disable auto-retrieval
    )
    await runner.run_all_tests()


if __name__ == "__main__":
    print("\n" + "🧪" * 30)
    print("  JotForm Payment Request - Test Suite Runner")
    print("  🤖 WITH AUTOMATED EMAIL LINK RETRIEVAL 🤖")
    print("  Automated Test Execution with Excel Reporting")
    print("🧪" * 30 + "\n")

    asyncio.run(main())
