"""
JotForm Payment Request Automation
A test automation suite for JotForm payment workflows
"""

__version__ = "1.0.0"
__author__ = "DigiBlun/ETG Test Automation Team"
__email__ = "your.email@digiblu.com"

from . import utils
from . import config

__all__ = ["utils", "config"]
